#-*- coding: utf-8 -*-
#Vstream https://github.com/Kodi-vStream/venom-xbmc-addons


param={}

class cInputParameterHandler:
    def getValue(self, key):
        global param
        try:
            value = param[key]
        except:
            value = '' 
        return value

    def setValue(self, paramInp):
        global param
        param = paramInp
        
    def exist(self, tt):
        return ''
        
