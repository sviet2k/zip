#-*- coding: utf-8 -*-
#Vstream https://github.com/Kodi-vStream/venom-xbmc-addons
command = ''
text = ''
class cGui:
    def get(self):
        return
    def addDir(self, site, showHosters, sTitle, sport, oOutputParameterHandler):
        return
    def setEndOfDirectory(self):
        return
    def addText(self, value,v2=''):
        global text
        text = v2
        return
    def addTV(self, SITE_IDENTIFIER, h, sTitle, sThumb, sThumb2, h2, oOutputParameterHandler):
        global command, text
        if 'Autres Saisons' not in text: # Patch for Zone Telecharge
            command = h
        return
    def addNext(self,SITE_IDENTIFIER, s, s2, oOutputParameterHandler):
        return
    def addMovie(self, SITE_IDENTIFIER, s, sTitle, s2, sThumb, s3, oOutputParameterHandler):
        global command
        command = s
        return
    def createContexMenuFav(self, oGuiElement, oOutputParameterHandler):
        return
    def CreateSimpleMenu(self, oGuiElement, oOutputParameterHandler, c1, c2, c3, c4):
        return
    def addHost(self, oGuiElement, oOutputParameterHandler):
        return
    def getCommand(self):
        global command
        return command
    def resetCommand(self):
        global command
        command = ''
    def addLink(self, SITE_IDENTIFIER, s, sDisplayTitle, sThumb, s2, oOutputParameterHandler):
        global command
        command = s
        return
