#-*- coding: utf-8 -*-
#Vstream https://github.com/Kodi-vStream/venom-xbmc-addons

# param key is utl, param value is parameters
param = {}

class cOutputParameterHandler:
    
    def __init__(self):
        global param
        self.param = {}
        
    def addParameter(self, key, value):
        global param
        self.param[key] = value
        if 'siteUrl' in self.param:
            param[self.param['siteUrl']] = self.param

    def printUrls(self):
        global param_urls
        for i in param_urls:
            print '[%s]' % i
            
    def resetUrls(self):
        global param
        param = {}
        return
     
    def getUrls(self):
        global param
        urls = []
        for i in param:
            urls.append(i)
        return urls

    def getParam(self):
        global param
        return param
