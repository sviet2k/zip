#-*- coding: utf-8 -*-
# https://github.com/Kodi-vStream/venom-xbmc-addons
#
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib.gui.gui import cGui

from resources.lib.comaddon import addon, dialog, xbmc, isKrypton, VSlog


#pour les sous titres
#https://github.com/amet/service.subtitles.demo/blob/master/service.subtitles.demo/service.py
#player API
#http://mirrors.xbmc.org/docs/python-docs/stable/xbmc.html#Player

class cPlayer():

    ADDON = addon()
    DIALOG = dialog()
    
    def __init__(self, *args):
        return
        
        
    def clearPlayList(self):
        return
    def __getPlayList(self):
        return

    def addItemToPlaylist(self, oGuiElement):
        oGui = cGui()
        oListItem =  oGui.createListItem(oGuiElement)
        self.__addItemToPlaylist(oGuiElement, oListItem)
    
    def __addItemToPlaylist(self, oGuiElement, oListItem):    
        oPlaylist = self.__getPlayList()    
        oPlaylist.add(oGuiElement.getMediaUrl(), oListItem )
        
    def AddSubtitles(self,files):
        if isinstance(files, basestring):
            self.Subtitles_file.append(files)
        else:
            self.Subtitles_file = files
        
    def run(self, oGuiElement, sTitle, sUrl):
        return
 
    #fonction light servant par exmple pour visualiser les DL ou les chaines de TV
    def startPlayer(self):
        oPlayList = self.__getPlayList()
        self.play(oPlayList)

    def onPlayBackEnded( self ):
        self.onPlayBackStopped()

    #Attention pas de stop, si on lance une seconde video sans fermer la premiere
    def onPlayBackStopped( self ):

        
        VSlog("player stoped")
        
        self.playBackStoppedEventReceived = True
        
        #calcul le temp de lecture
        pourcent =  float("%.2f" % (self.currentTime / self.totalTime))
        if (pourcent > 0.90):
            
            # Marqué VU dans la BDD Vstream
            cGui().setWatched()

            # Marqué VU dans les comptes perso
            try:
                tmdb_session = self.ADDON.getSetting('tmdb_session')
                if tmdb_session:
                    self.__getWatchlist('tmdb')
                bstoken = self.ADDON.getSetting("bstoken")
                if bstoken:
                    self.__getWatchlist('trakt')
            except:
                pass

        #xbmc.executebuiltin( 'Container.Refresh' )
        
    def onPlayBackStarted(self):
        
        VSlog("player started")
        
        #Si on recoit une nouvelle fois l'event, c'est que ca buggue, on stope tout
        if self.playBackEventReceived:
            self.forcestop = True
            return
        
        self.playBackEventReceived = True

    def __getWatchlist(self, sAction):

        if sAction == 'tmdb':
            plugins = __import__('resources.sites.themoviedb_org', fromlist=['themoviedb_org'])
            function = getattr(plugins, 'getWatchlist')
            function()
        elif sAction == 'trakt':
            #plugins = __import__('resources.lib.trakt', fromlist=['cTrakt'])
            plugins = __import__('resources.lib.trakt', fromlist=['trakt']).cTrakt()
            function = getattr(plugins, 'getWatchlist')
            function()
            
        return

        
    def __getPlayerType(self):
        sPlayerType = self.ADDON.getSetting('playerType')
        
        try:
            if (sPlayerType == '0'):
                VSlog("playertype from config: auto")
                return xbmc.PLAYER_CORE_AUTO

            if (sPlayerType == '1'):
                VSlog("playertype from config: mplayer")
                return xbmc.PLAYER_CORE_MPLAYER

            if (sPlayerType == '2'):
                VSlog("playertype from config: dvdplayer")
                return xbmc.PLAYER_CORE_DVDPLAYER
        except:
            return False
            
    def enable_addon(self,addon):
        #import json
        #sCheck = {'jsonrpc': '2.0','id': 1,'method': 'Addons.GetAddonDetails','params': {'addonid':'inputstream.adaptive','properties': ['enabled']}}
        #response = xbmc.executeJSONRPC(json.dumps(sCheck))
        #data = json.loads(response)
        #if not 'error' in data.keys():      
        #if data['result']['addon']['enabled'] == False:
        
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)') == 0:
            do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"inputstream.adaptive","enabled":true}}'
            query = xbmc.executeJSONRPC(do_json)
            VSlog("Activation d'inputstream.adaptive")
        else:
            VSlog('inputstream.adaptive déjà activé')
