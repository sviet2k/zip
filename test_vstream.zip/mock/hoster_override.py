#-*- coding: utf-8 -*-
import re
from mock.hoster import cHosterGui as realHosterGui
#from resources.lib.gui.hoster import cHosterGui

param_urls = []
param = {'sMovieTitle2':'2','sMovieTitle4':'4', 'urls':param_urls}
host_urls = []
non_supports = []

class cHosterGui(realHosterGui):

    def checkHosterDelete(self, value):
        return self
    def setDisplayName(self, sMovieTitle2):
        return
    def setFileName(self, sMovieTitle2):
        return
    def showHoster(self, oGui, oHoster, sHosterUrl, sThumb):
        host_urls.append(sHosterUrl)            
    def printHosts(self):
        print "\nPrint Params"
        for i in host_urls:
            print i
        return
    def getHosts(self):
        return host_urls
    def setParam(self, key, value):
        param[key] = value
    def resetHosts(self):
        global host_urls
        host_urls = []

    def checkHoster(self, sHosterUrl):
        global non_supports
        cc = realHosterGui().checkHoster(sHosterUrl)
        if cc:
            return cc
        else:
            m = re.search('\/\/(.*?)\/', sHosterUrl)
            if m:
                sHosterUrl = m.group(1)
            if sHosterUrl not in non_supports:
                non_supports.append(sHosterUrl)
            return False
    
    def getNonSupport(self):
        global non_supports
        return non_supports