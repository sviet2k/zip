#-*- coding: utf-8 -*-
#Vstream https://github.com/Kodi-vStream/venom-xbmc-addons

import time

def sleep(a):
        a = a/1000
        time.sleep(a)
        return

class progress:
    def VScreate(self, str):
        #print str
        return self
    def VSupdate(self,t,t2):
        return
    def iscanceled(self):
        return False
    def VSclose(self, progress):
        return

class xbmc:
    @staticmethod
    def sleep(a):
        a = a/1000
        print "   Sleep: %s sec" % a
        time.sleep(a)
        return
        

class xbmcgui:
    def mock(self):
        return

class window:
    def mock(self):
        return

class listitem:
    def mock(self):
        return

class addon():

    #def __init__(self, id='plugin.video.vstream'):
    #    xbmcaddon.__init__(id)
    #    pass

    def VSlang(self, lang):
        return

    #deprecier utiliser addons.setSetting et addons.getSetting
    def VSsetting(self, name, value=False):
        return
    
    def getSetting(self, tt):
        return ''

    def setSetting(self, aa, bb):
        return True
    
class dialog():

    #def __init__(self):
    #    xbmcgui.__init__('')
    #    pass
    
    def VSok(self, desc, title='vStream'):
        return self
    def VSinfo(self, s1, s2, s3):
        return ''
    def VSselectqual(self, qual, url):
        return url    
    def VSerror(self, e):
        print ('Erreur: ' + str(e))

def VSlog(e, level=1):
    return

def isKrypton():
    return True
    