#-*- coding: utf-8 -*-


# Mock Vstream Modules
def _import(name, *args, **kwargs):
    if name == 'resources.lib.handler.outputParameterHandler':
        name = 'mock.outputParameterHandler'
    elif name == 'resources.lib.handler.inputParameterHandler':
        name = 'mock.inputParameterHandler'
    elif name == 'resources.lib.gui.hoster':
        name = 'mock.hoster_override'
    elif name == 'resources.lib.gui.gui':
        name = 'mock.gui'
    elif name == 'resources.lib.comaddon':
        name = 'mock.comaddon'
    elif name == 'xbmcgui':
        name = 'mock.comaddon'
    elif name == 'xbmcaddon':
        name = 'mock.comaddon'
    elif name == 'xbmcvfs':
        name = 'mock.comaddon'
    elif name == 'resources.lib.gui.guiElement':
        name = 'mock.guiElement'        
    elif name == 'resources.lib.player':
        name = 'mock.player'

    return original_import(name, *args, **kwargs)

original_import = __builtins__.__import__
__builtins__.__import__ = _import

from mock import outputParameterHandler
from mock import inputParameterHandler
#from mock import hoster
from mock import hoster_override as hoster
from mock import gui

from importlib import import_module
from random import randint
import time
import urllib3
urllib3.disable_warnings()

aHosterGui = hoster.cHosterGui()

def vstreamDecode(host, okHosts, errorHosts, nfHosts):
    turl = []
    
    cHost = aHosterGui.checkHoster(host)
    cHost.setUrl(host)
    hostName = cHost.getDisplayName()
    try:
        if hostName in okHosts or hostName in errorHosts:
            #print " Decoding done for %s" % hostName
            return turl
        ok, urls = cHost.getMediaLink()
        if ok:
            if type(urls) is list:
                for url in urls:
                    turl.append({host:url})
            else:
                turl.append({host:urls})
            okHosts.append(hostName)
        else:
            #errorHosts.append(hostName)
            if hostName not in nfHosts:
                nfHosts.append(hostName)
                print "      Not found: %s" % host
        
    except Exception as e:
        if hostName not in errorHosts:
            errorHosts.append(hostName)
            print "      Error during decoding: %s [%s]" % (host,e)

    return turl

def decodeHosts(hosts):
    turl = []
    okHosts = []
    errHosts = []
    nfHosts = []
    for host in hosts:
        for i in vstreamDecode(host, okHosts, errHosts, nfHosts):
            turl.append(i)
    
    okHosts = set(okHosts)
    errHosts = set(errHosts)
    print "   Host OK: %s, Error: %s" % (list(okHosts), list(errHosts))              
    return turl

def runCmd(source, url, cmd):
    time.sleep(15)
    try:
        tmp = inputParameterHandler.param
        if url in tmp:
            inputParameterHandler.param = tmp[url]
        else:
            inputParameterHandler.param['siteUrl'] = url
        getattr(source, cmd)()
    except Exception as e:
        print str(e)
        pass

    cmd = gui.command
    gui.command = ''
    gui.text = ''
    
    urls = []
    for i in outputParameterHandler.param:
        urls.append(i)
    
    hosts = hoster.host_urls    
    if hosts:
        hoster.host_urls = []
        inputParameterHandler.param = {}
    else:
        inputParameterHandler.param = outputParameterHandler.param    
    outputParameterHandler.param = {}
    
    return cmd, urls, hosts

def findHostsLinks(source, inp, cmd, med):
    # Recursive function to navigate all pages
    if 'sMovieTitle' not in inp:
        return ''
    
    url = inp['siteUrl']
    cmd2, med2, hosts = runCmd(source, url, cmd)
    
    if hosts:
        print '%s - %s - Found %s Hosts - [%s]' % (inp['sMovieTitle'], cmd, len(med), url)
        return hosts, med, cmd
    elif med2:
        print '%s - %s - Found %s Medias - [%s]' % (inp['sMovieTitle'], cmd, len(med2), url)
        url = med2[randint(0,len(med2)-1)]
        inp = inputParameterHandler.param[url]
        hosts, med2, cmd = findHostsLinks(source, inp, cmd2, med2)

    return hosts, med2, cmd

def navigate(source, inp, cmd):
    hostsFound = []
    # Recursive function
    hosts, links, cmd2 = findHostsLinks(source, inp, cmd, [])
    if hosts and links:
        for url in links:
            hosts2 = runCmd(source, url, cmd2)[2]
            if hosts2:
                for i in hosts2:
                    hostsFound.append(i)
    
    turl = []          
    if hostsFound:
        print '   From %s Hosts Found %s Hosts can be decoded' % (len(links), len(hostsFound))
        print '   Start decoding ...'
        turl = decodeHosts(hostsFound)
        #print "   Found %s Direct Links" % (len(turl))             
        #for i in turl:
            #print "      %s" % i
        
        nonSupport = aHosterGui.getNonSupport()
        if nonSupport:
            print "   Non-Support Hosts: %s" % nonSupport
        
    return turl

def test_site(source, mainUrl, mainCmd, maxNb, site):
    
    # Get Series
    cmdSerie, medias, hosts = runCmd(source, mainUrl, mainCmd)
    if not medias:
        print "\n=== Test: %s. Error to get medias." % (site)
        return
    print "\n=== Test: %s Found %s Medias" % (site, len(medias))
    if maxNb > len(medias): maxNb = len(medias)
    mainParam = inputParameterHandler.param
    nb = 0
    nbTestOk = 0
    randoms = []
    while nbTestOk < maxNb:
        # Get randomly one series
        randNb = randint(0,len(medias)-1)
        while randNb in randoms: # RIsk infinite loop :)
            randNb = randint(0,len(medias)-1)
        randoms.append(randNb)
        
        media = medias[randNb]
        inp = mainParam[media]
        if 'sMovieTitle' not in inp: # Next Page
            continue
        
        # Start navigating
        print "\n=== Media: %s (%s/%s) Run %s" % (inp['sMovieTitle'], nbTestOk+1, maxNb, nb+1)
        turl= navigate(source, inp, cmdSerie)
        if turl:
            nbTestOk += 1
        
            
        nb += 1
        if nb - maxNb > 5:
            break


#================== MAIN =============


testNb  = 2
sites = [
    
    ['voirfilms_org','https://www.voir-films.info/series-tv-streaming/', testNb, 'Voir Film'],
    ['cinemay_com', 'https://www.cinemay.li/serie-streaming/', testNb, 'Cinemay'],
    #['streaming_series_xyz','https://dpstreaming.to/serie-category/series/', testNb, 'DP Streaming'],
    ]

for site in sites:
    source = import_module('resources.sites.' + site[0])
    if 'zone_telechargement_ws' == site[0]: # Patch for Zone teles
        source.URL_MAIN = 'https://www.zone-annuaire.com/'
    test_site(source, site[1], 'showMovies', site[2], site[3])
    
print "================== END"

